package controller;

import app.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Barang;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.sql.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class BarangController {

    @FXML private TextField tfKode, tfNama, tfHarga, tfStok;
    @FXML private TableView<Barang> tableBarang;
    @FXML private TableColumn<Barang, String> colKode, colNama, colSatuan;
    @FXML private TableColumn<Barang, Integer> colHarga, colStok;

    @FXML private ToggleGroup satuanGroup;
    @FXML private RadioButton rbPcs, rbLiter, rbGalon, rbPax;
    @FXML private TextField tfStokBaru;

    private ObservableList<Barang> dataBarang = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colKode.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getKodeBarang()));
        colNama.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNamaBarang()));
        colHarga.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getHarga()).asObject());
        colStok.setCellValueFactory(d -> new SimpleIntegerProperty(d.getValue().getStok()).asObject());
        colSatuan.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getSatuan()));

        tableBarang.setItems(dataBarang);
        loadData();
    }

    private void loadData() {
        dataBarang.clear();
        try (Connection conn = Database.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM tbl_barang")) {

            while (rs.next()) {
                dataBarang.add(new Barang(
                        rs.getString("kode_barang"),
                        rs.getString("nama_barang"),
                        rs.getInt("harga_barang"),
                        rs.getInt("stok_barang"),
                        rs.getString("satuan")
                ));
            }

        } catch (SQLException e) {
            showAlert("Error load data: " + e.getMessage());
        }
    }

    private String getSatuanTerpilih() {
        RadioButton selected = (RadioButton) satuanGroup.getSelectedToggle();
        return selected != null ? selected.getText() : "";
    }

    @FXML
    private void tambahBarang() {
        String kode = tfKode.getText();
        String nama = tfNama.getText();
        int harga = Integer.parseInt(tfHarga.getText());
        int stok = Integer.parseInt(tfStok.getText());
        String satuan = getSatuanTerpilih();

        if (satuan.isEmpty()) {
            showAlert("Pilih satuan terlebih dahulu.");
            return;
        }

        String sql = "INSERT INTO tbl_barang (kode_barang, nama_barang, harga_barang, stok_barang, satuan) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kode);
            ps.setString(2, nama);
            ps.setInt(3, harga);
            ps.setInt(4, stok);
            ps.setString(5, satuan);
            ps.executeUpdate();

            showAlert("Barang berhasil ditambahkan!");
            tfKode.clear(); tfNama.clear(); tfHarga.clear(); tfStok.clear(); satuanGroup.selectToggle(null);
            loadData();
        } catch (SQLException e) {
            showAlert("Gagal tambah barang: " + e.getMessage());
        }
    }

    @FXML
    private void kembaliKeMenu(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/main_menu.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Menu Utama");
        } catch (IOException e) {
            showAlert("Gagal kembali ke menu: " + e.getMessage());
        }
    }

    private void showAlert(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }
}
